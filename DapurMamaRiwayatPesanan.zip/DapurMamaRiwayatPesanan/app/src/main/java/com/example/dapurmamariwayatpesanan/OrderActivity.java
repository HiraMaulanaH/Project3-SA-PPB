package com.example.dapurmamariwayatpesanan;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class OrderActivity extends AppCompatActivity {

    private int jumlah = 1;
    private int hargaItem,gambarItem;
    private Button btnOrderrr;
    private TextView txtQuantity,txtTotalHarga,namaMenu,deskripsiMenu,hargaMenu;
    private ImageView gambarMenu;
    private String namaItem,deskripsiItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        txtQuantity = findViewById(R.id.txtQuantity);
        txtTotalHarga = findViewById(R.id.idTotal);

        Intent intent = getIntent();
        namaItem = intent.getStringExtra("namaItem");
        deskripsiItem = intent.getStringExtra("deskripsiItem");
        hargaItem = intent.getIntExtra("hargaItem", 0);
        gambarItem = intent.getIntExtra("gambarItem", R.drawable.es_teh);

        btnOrderrr = findViewById(R.id.btnPesanMenu);
        gambarMenu = findViewById(R.id.idGambar);
        namaMenu = findViewById(R.id.idNama);
        deskripsiMenu = findViewById(R.id.idDeskripsi);
        hargaMenu = findViewById(R.id.idHarga);

        gambarMenu.setImageResource(gambarItem);
        namaMenu.setText(namaItem);
        deskripsiMenu.setText(deskripsiItem);
        hargaMenu.setText("Harga: Rp " + hargaItem);

        updateQuantityAndTotal();

        btnOrderrr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int totalBayar = jumlah * hargaItem;

                SharedPreferences sharedPreferences = getSharedPreferences("pembelian", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                int orderanKe = sharedPreferences.getInt("order_count", 0);

                String orderKey = "order_" + orderanKe;

                editor.putString(orderKey + "saveNamaMenu", namaItem); // Save the item name
                editor.putInt(orderKey + "saveJumlahPesanan", jumlah);
                editor.putInt(orderKey + "saveTotalBayar", (int) totalBayar);

                editor.putInt("order_count", orderanKe + 1);
                editor.apply();

                Intent intent = new Intent(OrderActivity.this, SuksesOrder.class);
                intent.putExtra("namaMakanan", namaItem);
                intent.putExtra("hargaMakanan", hargaItem);
                intent.putExtra("jumlahPesan", jumlah);
                startActivity(intent);
                finish();
            }
        });
    }

    public void tambahJumlah(View view){
        jumlah++;
        updateQuantityAndTotal();
    }

    public void kurangJumlah(View view){
        if (jumlah > 1) {
            jumlah--;
            updateQuantityAndTotal();
        }
    }

    private void updateQuantityAndTotal() {

        txtQuantity.setText(String.valueOf(jumlah));
        int totalHarga = jumlah * hargaItem;
        txtTotalHarga.setText("Total Harga: Rp " + totalHarga);
    }
}