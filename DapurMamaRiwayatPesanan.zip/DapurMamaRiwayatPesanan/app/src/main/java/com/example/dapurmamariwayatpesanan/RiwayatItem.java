package com.example.dapurmamariwayatpesanan;

public class RiwayatItem {

    private String namaPesanan;
    private String totalHargaPesanan;
    private String tanggalOrder;
    private String metodePembayaranOrder;

    public RiwayatItem(String itemPesanan, String totalHarga, String tanggal, String metodePembayaran) {
        this.namaPesanan = itemPesanan;
        this.totalHargaPesanan = totalHarga;
        this.tanggalOrder = tanggal;
        this.metodePembayaranOrder = metodePembayaran;
    }

    public String getItemPesanan() {
        return namaPesanan;
    }

    public String getTotalHarga() {
        return totalHargaPesanan;
    }

    public String getTanggal() {
        return tanggalOrder;
    }

    public String getMetodePembayaran() {
        return metodePembayaranOrder;
    }
}
