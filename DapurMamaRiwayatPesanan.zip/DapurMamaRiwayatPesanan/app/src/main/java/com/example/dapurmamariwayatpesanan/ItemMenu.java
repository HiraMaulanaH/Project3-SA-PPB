package com.example.dapurmamariwayatpesanan;

public class ItemMenu {

    private String menuNama;
    private String menuDeskripsi;
    private int menuHarga;
    private int menuGambar;

    public String getMenuNama() {
        return menuNama;
    }

    public void setMenuNama(String menuNama) {
        this.menuNama = menuNama;
    }

    public String getMenuDeskripsi() {
        return menuDeskripsi;
    }

    public void setMenuDeskripsi(String menuDeskripsi) {
        this.menuDeskripsi = menuDeskripsi;
    }

    public int getMenuHarga() {
        return menuHarga;
    }

    public void setMenuHarga(int menuHarga) {
        this.menuHarga = menuHarga;
    }

    public int getMenuGambar() {
        return menuGambar;
    }

    public void setMenuGambar(int menuGambar) {
        this.menuGambar = menuGambar;
    }

    public ItemMenu(String namanya, String deskripsinya, int harganya, int gambarnya) {
        this.menuNama = namanya;
        this.menuDeskripsi = deskripsinya;
        this.menuHarga = harganya;
        this.menuGambar = gambarnya;
    }
}
