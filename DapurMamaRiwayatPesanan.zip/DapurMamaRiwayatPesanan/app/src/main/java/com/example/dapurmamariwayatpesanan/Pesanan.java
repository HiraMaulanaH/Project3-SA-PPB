package com.example.dapurmamariwayatpesanan;

import java.util.Date;
import java.util.List;

public class Pesanan {
    private List<ItemMenu> items;
    private String menu;
    private int hargaMenu;
    private int quantity;
    private int totalHarga;
    private Date tanggal;
    private String metodePembayaran;

    public Pesanan(String itemName, int harga, int quantity, int totalHarga, Date tanggal) {
        this.menu = itemName;
        this.hargaMenu = harga;
        this.quantity = quantity;
        this.totalHarga = totalHarga;
        this.tanggal = tanggal;
    }

    public Pesanan(List<ItemMenu> items) {
        this.items = items;
        calculateTotalHarga();
    }
    private void calculateTotalHarga() {
        totalHarga = 0;
        for (ItemMenu item : items) {
            totalHarga += item.getMenuHarga();
        }
    }

    public List<ItemMenu> getItems() {
        return items;
    }

    public int getTotalHarga() {
        return totalHarga;
    }

    public String getItemName() {
        return menu;
    }

    public int getTotalPrice() {
        return totalHarga;
    }

    public int getQuantity() {
        return quantity;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public String getMetodePembayaran() {
        return metodePembayaran;
    }

}

